<!-- Start Code -->
<?php
    $koneksi = new mysqli ("localhost","riyadhul_user","S0ck3tM@ch1n3","riyadhul_tagihan");
?>
<!-- End Code -->